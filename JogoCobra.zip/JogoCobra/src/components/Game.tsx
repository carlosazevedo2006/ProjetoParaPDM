import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  PanResponder,
  Animated,
  Alert,
  TouchableOpacity,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { DIRECOES, CELULA, GRID_SIZE, gerarComida, igual } from "../utils/constants";
import { Posicao } from "../types/types";

const { width } = Dimensions.get("window");

// ✅ SEM DELAY - Threshold mínimo para evitar toques acidentais
const SWIPE_THRESHOLD = 15;

// ✅ CONFIGURAÇÃO DAS VALORIZAÇÕES (fácil de ajustar)
const CONFIG = {
  velocidadeBase: 150, // Mais rápido (150ms)
  velocidadeMinima: 60,
  reducaoPorComida: 5,
  cobraInimigaAtiva: true,
  velocidadeInimigaFactor: 0.85, // Inimiga 15% mais rápida
  corCobraJogador: "#43a047",
  corCobraInimiga: "#8e24aa",
  corComida: "#e53935",
  corTabuleiro: "#ffffff",
};

export default function Game() {
  const centro = Math.floor(GRID_SIZE / 2);

  // Estados do jogo
  const [cobra, setCobra] = useState<Posicao[]>([{ x: centro, y: centro }]);
  const [direcao, setDirecao] = useState<Posicao>(DIRECOES.DIREITA);
  const [cobraInimiga, setCobraInimiga] = useState<Posicao[]>([
    { x: centro - 3, y: centro - 3 },
  ]);
  const [direcaoInimiga, setDirecaoInimiga] = useState<Posicao>(DIRECOES.ESQUERDA);
  const [comida, setComida] = useState<Posicao>(() => gerarComida([{ x: centro, y: centro }]));
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);

  // ✅ CONTAGEM REGRESSIVA (substitui "toque para começar")
  const [contagem, setContagem] = useState<number | null>(3); // 3, 2, 1, null

  const direcaoRef = useRef(direcao);
  const contagemRef = useRef(contagem);
  direcaoRef.current = direcao;
  contagemRef.current = contagem;

  // Carregar high score
  useEffect(() => {
    AsyncStorage.getItem("highScore").then((value) => {
      if (value) setHighScore(parseInt(value));
    });
  }, []);

  // Guardar high score
  useEffect(() => {
    if (gameOver && score > highScore) {
      setHighScore(score);
      AsyncStorage.setItem("highScore", score.toString());
    }
  }, [gameOver, score, highScore]);

  // ✅ CONTAGEM REGRESSIVA - Efeito principal
  useEffect(() => {
    if (contagem === null) return; // Jogo já começou

    const intervalo = setInterval(() => {
      setContagem((prev) => {
        if (prev === null) return prev;
        if (prev === 1) {
          return null; // Contagem terminou, jogo começa
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(intervalo);
  }, [contagem]);

  // ✅ VELOCIDADE DINÂMICA (aumenta com pontuação)
  const getGameSpeed = useCallback(() => {
    const reducao = score * CONFIG.reducaoPorComida;
    return Math.max(CONFIG.velocidadeMinima, CONFIG.velocidadeBase - reducao);
  }, [score]);

  // ✅ COBRA INIMIGA - IA (apenas 4 direções, nunca diagonal)
  const moverCobraInimiga = useCallback(() => {
    setCobraInimiga((prev) => {
      const cabeca = prev[0];
      
      // IA: Persegue comida ou movimento aleatório válido
      let novaDirecao = direcaoInimiga;
      
      // 70% chance de perseguir a comida
      if (Math.random() > 0.3) {
        const dx = comida.x - cabeca.x;
        const dy = comida.y - cabeca.y;
        
        // Escolhe direção que reduz maior distância, sem inverter
        if (Math.abs(dx) > Math.abs(dy)) {
          novaDirecao = dx > 0 ? DIRECOES.DIREITA : DIRECOES.ESQUERDA;
          if (novaDirecao.x === -direcaoInimiga.x) novaDirecao = dy > 0 ? DIRECOES.BAIXO : DIRECOES.CIMA;
        } else {
          novaDirecao = dy > 0 ? DIRECOES.BAIXO : DIRECOES.CIMA;
          if (novaDirecao.y === -direcaoInimiga.y) novaDirecao = dx > 0 ? DIRECOES.DIREITA : DIRECOES.ESQUERDA;
        }
      } else {
        // 30% movimento aleatório válido
        const direcoesValidas = [
          DIRECOES.CIMA,
          DIRECOES.BAIXO,
          DIRECOES.ESQUERDA,
          DIRECOES.DIREITA,
        ].filter((d) => !(d.x === -direcaoInimiga.x && d.y === -direcaoInimiga.y));
        novaDirecao = direcoesValidas[Math.floor(Math.random() * direcoesValidas.length)];
      }

      setDirecaoInimiga(novaDirecao);

      // Movimento (wrap-around nas bordas)
      let novaCabeca = {
        x: cabeca.x + novaDirecao.x,
        y: cabeca.y + novaDirecao.y,
      };

      if (novaCabeca.x < 0) novaCabeca.x = GRID_SIZE - 1;
      if (novaCabeca.x >= GRID_SIZE) novaCabeca.x = 0;
      if (novaCabeca.y < 0) novaCabeca.y = GRID_SIZE - 1;
      if (novaCabeca.y >= GRID_SIZE) novaCabeca.y = 0;

      let novaCobra = [novaCabeca, ...prev];

      // Se inimiga comer comida, gera nova (mas não ganha pontos)
      if (igual(novaCabeca, comida)) {
        setComida(gerarComida([...cobra, ...novaCobra]));
      } else {
        novaCobra.pop();
      }

      return novaCobra;
    });
  }, [direcaoInimiga, comida, cobra]);

  // Loop da cobra inimiga
  useEffect(() => {
    if (!CONFIG.cobraInimigaAtiva || contagem !== null) return;
    
    const interval = setInterval(() => {
      moverCobraInimiga();
    }, getGameSpeed() * CONFIG.velocidadeInimigaFactor);

    return () => clearInterval(interval);
  }, [moverCobraInimiga, getGameSpeed, contagem]);

  // ✅ PANRESPONDER - Resposta IMEDIATA, sem delay
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderRelease: (_, gestureState) => {
        const { dx, dy } = gestureState;

        // Ignorar gestos muito curtos (toques acidentais)
        if (Math.abs(dx) < SWIPE_THRESHOLD && Math.abs(dy) < SWIPE_THRESHOLD) {
          return;
        }

        // ✅ APENAS 4 DIREÇÕES ORTOGONAIS - Sem diagonais
        if (Math.abs(dx) > Math.abs(dy)) {
          // Horizontal
          if (dx > 0 && direcaoRef.current !== DIRECOES.ESQUERDA) {
            setDirecao(DIRECOES.DIREITA);
          } else if (dx < 0 && direcaoRef.current !== DIRECOES.DIREITA) {
            setDirecao(DIRECOES.ESQUERDA);
          }
        } else {
          // Vertical
          if (dy > 0 && direcaoRef.current !== DIRECOES.CIMA) {
            setDirecao(DIRECOES.BAIXO);
          } else if (dy < 0 && direcaoRef.current !== DIRECOES.BAIXO) {
            setDirecao(DIRECOES.CIMA);
          }
        }
      },
    })
  ).current;

  // ✅ LOOP PRINCIPAL DO JOGO (só corre após contagem)
  useEffect(() => {
    if (contagem !== null || gameOver) return;

    const interval = setInterval(() => {
      setCobra((prev) => {
        const cabeca = prev[0];
        const novaCabeca = {
          x: cabeca.x + direcaoRef.current.x,
          y: cabeca.y + direcaoRef.current.y,
        };

        // Colisão com parede
        if (
          novaCabeca.x < 0 ||
          novaCabeca.x >= GRID_SIZE ||
          novaCabeca.y < 0 ||
          novaCabeca.y >= GRID_SIZE
        ) {
          setGameOver(true);
          return prev;
        }

        // Colisão com próprio corpo (ignora último segmento que vai mover)
        if (prev.slice(1).some((seg) => igual(seg, novaCabeca))) {
          setGameOver(true);
          return prev;
        }

        // Colisão com cobra inimiga
        if (CONFIG.cobraInimigaAtiva && cobraInimiga.some((seg) => igual(seg, novaCabeca))) {
          setGameOver(true);
          return prev;
        }

        let novaCobra = [novaCabeca, ...prev];

        // Apanhar comida
        if (igual(novaCabeca, comida)) {
          setScore((s) => s + 1);
          setComida(gerarComida(novaCobra));
        } else {
          novaCobra.pop();
        }

        return novaCobra;
      });
    }, getGameSpeed());

    return () => clearInterval(interval);
  }, [contagem, gameOver, comida, getGameSpeed, cobraInimiga]);

  const reiniciar = () => {
    setCobra([{ x: centro, y: centro }]);
    setDirecao(DIRECOES.DIREITA);
    setCobraInimiga([{ x: centro - 3, y: centro - 3 }]);
    setDirecaoInimiga(DIRECOES.ESQUERDA);
    setComida(gerarComida([{ x: centro, y: centro }]));
    setScore(0);
    setGameOver(false);
    setContagem(3); // ✅ Reinicia contagem
  };

  // Renderizar célula
  const renderCelula = (x: number, y: number) => {
    const isCobra = cobra.some((seg) => seg.x === x && seg.y === y);
    const isCabeca = cobra[0]?.x === x && cobra[0]?.y === y;
    const isComida = comida.x === x && comida.y === y;
    const isInimiga = cobraInimiga.some((seg) => seg.x === x && seg.y === y);
    const isCabecaInimiga = cobraInimiga[0]?.x === x && cobraInimiga[0]?.y === y;

    return (
      <View
        key={`${x}-${y}`}
        style={[
          styles.celula,
          {
            backgroundColor: isCabeca
              ? "#2e7d32"
              : isCobra
              ? CONFIG.corCobraJogador
              : isCabecaInimiga
              ? "#6a1b9a"
              : isInimiga
              ? CONFIG.corCobraInimiga
              : isComida
              ? CONFIG.corComida
              : CONFIG.corTabuleiro,
          },
        ]}
      />
    );
  };

  return (
    <View style={styles.container}>
      {/* Cabeçalho fixo no topo */}
      <View style={styles.header}>
        <Text style={styles.scoreText}>Score: {score}</Text>
        <Text style={styles.scoreText}>High: {highScore}</Text>
      </View>

      {/* Tabuleiro - SEM position: absolute, centralizado corretamente */}
      <View style={styles.gameArea}>
        <View style={styles.grid} {...panResponder.panHandlers}>
          {Array.from({ length: GRID_SIZE }).map((_, y) =>
            Array.from({ length: GRID_SIZE }).map((_, x) => renderCelula(x, y))
          )}
        </View>
      </View>

      {/* ✅ CONTAGEM REGRESSIVA */}
      {contagem !== null && (
        <View style={styles.contagemContainer}>
          <Text style={styles.contagemText}>{contagem}</Text>
        </View>
      )}

      {/* Game Over */}
      {gameOver && (
        <View style={styles.overlay}>
          <Text style={styles.gameOverText}>GAME OVER</Text>
          <Text style={styles.scoreText}>Score: {score}</Text>
          <TouchableOpacity style={styles.restartButton} onPress={reiniciar}>
            <Text style={styles.restartText}>Reiniciar</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121212",
    alignItems: "center",
    // NÃO usar justifyContent: "center" aqui - deixa o cabeçalho no topo
  },
  header: {
    width: "100%",
    paddingTop: 50,
    paddingBottom: 20,
    flexDirection: "row",
    justifyContent: "space-around",
    backgroundColor: "#1a1a1a",
    borderBottomWidth: 2,
    borderBottomColor: "#333",
  },
  scoreText: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "bold",
  },
  gameArea: {
    flex: 1,
    justifyContent: "center", // Centraliza o grid verticalmente
    alignItems: "center",     // Centraliza o grid horizontalmente
    paddingVertical: 20,      // Espaço em cima e em baixo
  },
  grid: {
    width: CELULA * GRID_SIZE,
    height: CELULA * GRID_SIZE,
    borderWidth: 3,
    borderColor: "#333",
    backgroundColor: CONFIG.corTabuleiro,
    flexDirection: "row",
    flexWrap: "wrap",
  },
  celula: {
    width: CELULA,
    height: CELULA,
    borderWidth: 0.5,
    borderColor: "#ddd",
  },
  contagemContainer: {
    position: "absolute",
    alignSelf: "center",
    top: "50%",
    transform: [{ translateY: -50 }],
  },
  contagemText: {
    color: "#fff",
    fontSize: 120,
    fontWeight: "bold",
    textAlign: "center",
  },
  overlay: {
    position: "absolute",
    alignItems: "center",
    top: "50%",
    transform: [{ translateY: -50 }],
  },
  gameOverText: {
    color: "#e53935",
    fontSize: 36,
    fontWeight: "bold",
    marginBottom: 10,
  },
  restartButton: {
    paddingHorizontal: 30,
    paddingVertical: 15,
    backgroundColor: "#43a047",
    borderRadius: 10,
    marginTop: 20,
  },
  restartText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
});