// src/types/index.ts

// Representa a posição de cada segmento da cobra e da comida
export interface Posicao {
  x: number;
  y: number;
}
