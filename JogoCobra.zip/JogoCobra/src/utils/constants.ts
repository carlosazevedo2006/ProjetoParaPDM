export const GRID_SIZE = 10; // FORÇADO 10x10
export const CELULA = 32;    // Tamanho de cada célula

export const DIRECOES = {
  CIMA: { x: 0, y: -1 },
  BAIXO: { x: 0, y: 1 },
  ESQUERDA: { x: -1, y: 0 },
  DIREITA: { x: 1, y: 0 },
} as const;

export function gerarComida(cobra: { x: number; y: number }[]) {
  let pos: { x: number; y: number };
  do {
    pos = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
  } while (cobra.some(seg => seg.x === pos.x && seg.y === pos.y));
  return pos;
}

export function igual(a: { x: number; y: number }, b: { x: number; y: number }) {
  return a.x === b.x && a.y === b.y;
}