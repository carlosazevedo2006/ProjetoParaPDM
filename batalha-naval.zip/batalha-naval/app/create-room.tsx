import CreateRoomScreen from '../src/screens/CreateRoomScreen';

export default CreateRoomScreen;
