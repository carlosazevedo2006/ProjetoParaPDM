export { default } from '../src/screens/GameScreen';
