export { default } from '../src/screens/HowToPlayScreen';
