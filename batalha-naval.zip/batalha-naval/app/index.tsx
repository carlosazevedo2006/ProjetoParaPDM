export { default } from '../src/screens/StartScreen';
