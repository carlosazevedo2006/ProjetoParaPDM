import JoinRoomScreen from '../src/screens/JoinRoomScreen';

export default JoinRoomScreen;
