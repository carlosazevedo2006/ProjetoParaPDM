export { default } from '../src/screens/MultiplayerConnectScreen';
