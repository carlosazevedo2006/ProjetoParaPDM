import MultiplayerModeScreen from '../src/screens/MultiplayerModeScreen';

export default MultiplayerModeScreen;
