export { default } from '../src/screens/ResultScreen';
