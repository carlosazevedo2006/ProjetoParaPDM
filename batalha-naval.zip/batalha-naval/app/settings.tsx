export { default } from '../src/screens/SettingsScreen';
