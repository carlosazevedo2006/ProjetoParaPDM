export { default } from '../src/screens/SetupScreen';
